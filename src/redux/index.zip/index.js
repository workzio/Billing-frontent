import { createStore } from "redux";
import { redux } from "./rootReducer";


export const store = createStore(redux);
