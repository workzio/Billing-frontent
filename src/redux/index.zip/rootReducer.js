import { combineReducers } from "redux";
import ProductReducers from "../Modules/HeadOffice/Product/ProductReducers";
import  MemberReducers from '../Modules/Admin/Member/MemberReducers'


export const redux = combineReducers({
     adminproduct: ProductReducers,
    adminmember : MemberReducers,
});

